from app.extensions import db
from datetime import datetime,UTC

class User(db.Model):
    __tablename__ = 'Users'

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    role = db.Column(db.String(20), default='operator')
    
    def to_dict(self):
        return {
            'id': self.id,
            'email': self.email,
            'role': self.role
        }

class Asset(db.Model):
    __tablename__ = 'Assets'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(50)) # 'solar', 'wind'
    location = db.Column(db.String(255))
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    rated_power_kw = db.Column(db.Float)
    status = db.Column(db.String(50), default='Active')

class SensorReading(db.Model):
    __tablename__ = 'SensorReadings'
    
    id = db.Column(db.Integer, primary_key=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('Assets.id'), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    temperature = db.Column(db.Float)
    vibration_rms = db.Column(db.Float)
    current = db.Column(db.Float)
    voltage = db.Column(db.Float)
    power_output_kw = db.Column(db.Float)
    wind_speed = db.Column(db.Float)
    soiling_level = db.Column(db.Float)

class Alert(db.Model):
    __tablename__ = 'Alerts'
    
    id = db.Column(db.Integer, primary_key=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('Assets.id'), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    anomaly_score = db.Column(db.Float)
    risk_level = db.Column(db.String(20)) # Low, Medium, High, Critical
    estimated_energy_loss = db.Column(db.Float)
    estimated_revenue_loss = db.Column(db.Float)
    status = db.Column(db.String(50), default='Open')

class MaintenanceLog(db.Model):
    __tablename__ = 'MaintenanceLogs'
    
    id = db.Column(db.Integer, primary_key=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('Assets.id'), nullable=False)
    alert_id = db.Column(db.Integer, db.ForeignKey('Alerts.id'), nullable=True)
    technician_id = db.Column(db.Integer, db.ForeignKey('Users.id'), nullable=False)
    action_taken = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.now(UTC))
    notes = db.Column(db.Text)

class WeatherForecast(db.Model):
    __tablename__ = "WeatherForecast"
    id = db.Column(db.Integer, primary_key=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('Assets.id'), nullable=False)
    temperature = db.Column(db.Float, nullable=False)
    solar_radiation = db.Column(db.Float, nullable=False)
    wind_speed = db.Column(db.Float, nullable=False)
    precipitation = db.Column(db.Float, nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.now(UTC))
    

class Prediction(db.Model):
    __tablename__ = "Prediction"
    id = db.Column(db.Integer, primary_key=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('Assets.id'), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.now(UTC))
    predicted_power_kw = db.Column(db.Float, nullable=False)
    predicted_anomaly_score = db.Column(db.Float, nullable=True)
    predicted_energy_loss = db.Column(db.Float, nullable=True)
    
